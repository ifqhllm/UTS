from django.urls import path
from . import views

urlpatterns = [
    path('ifqoh', views.ifqoh, name='ifqoh'),
]