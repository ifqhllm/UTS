from django.contrib import admin
from django.urls import include, path
from ali.views  import *

urlpatterns = [
    path('', index, name='index'),
    path('about', about, name='about'),
    path('clients', clients, name='clients'),
    path('contact', contact, name='contact'),
    path('testmonial', testmonial, name='testmonial'),
    path('admin/', admin.site.urls),
]