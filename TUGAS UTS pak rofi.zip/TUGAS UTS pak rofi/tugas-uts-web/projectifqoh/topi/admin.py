from django.contrib import admin
from .models import Model_topi

# Register your models here.
admin.site.register(Model_topi)
